package appointment;

import java.util.Date;

public class Appointment
{
    private final String appointmentID;
    private Date appointmentDate;
    private String description;
    
    public Appointment(final String appointmentID, final Date appointmentDate, final String description) {
        if (appointmentID == null || appointmentID.isEmpty()) {
            throw new IllegalArgumentException("Appointment ID cannot be null or empty");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        if (description == null || description.isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description length exceeds 50 characters");
        }
        this.appointmentID = appointmentID;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }
    
    public String getAppointmentID() {
        return this.appointmentID;
    }
    
    public Date getAppointmentDate() {
        return this.appointmentDate;
    }
    
    public void setAppointmentDate(final Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        this.appointmentDate = appointmentDate;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        if (description == null || description.isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Description length exceeds 50 characters");
        }
        this.description = description;
    }
    
    @Override
    public String toString() {
        return "Appointment [ appointmentID= " + this.appointmentID + ", appointmentDate = " + this.appointmentDate + ", description = " + this.description + "]";
    }
}
