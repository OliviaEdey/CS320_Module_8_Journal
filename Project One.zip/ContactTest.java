package contactTest;

import org.junit.Test;
import org.junit.Assert;
import contact.Contact;
import org.junit.Before;

public class ContactTest
{
    @Before
    public void setUp() throws Exception {
    }
    
    @Test
    public void testValidContactCreation() {
        final Contact contact = new Contact("C1", "Don", "Smith", "1234567890", "2 Silver St");
        Assert.assertEquals((Object)"C1", (Object)contact.getContactID());
        Assert.assertEquals((Object)"Don", (Object)contact.getFirstName());
        Assert.assertEquals((Object)"Smith", (Object)contact.getLastName());
        Assert.assertEquals((Object)"1246835790", (Object)contact.getPhoneNumber());
        Assert.assertEquals((Object)"2 Silver St", (Object)contact.getAddress());
    }
    
    @Test
    public void testInvalidContactCreation() {
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact(null, "Don", "Smith", "1246835790", "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C2", null, "Smith", "1246835790", "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C3", "Don", null, "1246835790", "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C4", "Don", "Smith", null, "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C5", "Don", "Smith", "1246835790", "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C6", "Don", "Smith", "1246835790", null));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C7", "Don0246810", "Smith", "1246835790", "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C8", "Don", "Smith0246810", "1246835790", "2 Silver St"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Contact("C9", "Don", "Smith", "1246835790", "1246835790124683579012468357902"));
    }
}
