package appointmentServiceTest;

import org.junit.Test;
import java.util.Date;
import org.junit.Assert;
import appointment.Appointment;
import java.util.Calendar;
import org.junit.Before;
import appointmentService.AppointmentService;

public class AppointmentServiceTest
{
    private AppointmentService appointmentService;
    
    @Before
    public void setUp() throws Exception {
        this.appointmentService = new AppointmentService();
    }
    
    @Test
    public void testAddAppointment() {
        final Calendar calendar = Calendar.getInstance();
        calendar.add(5, 1);
        final Date appointmentDate = calendar.getTime();
        final Appointment appointment = new Appointment("A1", appointmentDate, "Meet with team");
        this.appointmentService.addAppointment(appointment);
        Assert.assertEquals((Object)appointment, (Object)this.appointmentService.getAppointment("A1"));
    }
    
    @Test
    public void testDeleteAppointment() {
        final Calendar calendar = Calendar.getInstance();
        calendar.add(5, 1);
        final Date appointmentDate = calendar.getTime();
        final Appointment appointment = new Appointment("A2", appointmentDate, "Meet with team");
        this.appointmentService.addAppointment(appointment);
        this.appointmentService.deleteAppointment("A2");
        Assert.assertNull((Object)this.appointmentService.getAppointment("A2"));
    }
    
    @Test
    public void testInvalidAppointmentDate() {
        final Calendar calendar = Calendar.getInstance();
        final Date pastDate = calendar.getTime();
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment("A3", pastDate, "Meet with team"));
        final Calendar calendarFuture = Calendar.getInstance();
        calendarFuture.add(5, 2);
        final Date futureDate = calendarFuture.getTime();
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> this.appointmentService.addAppointment(new Appointment("A5", futureDate, "Meet with team")));
    }
    
    @Test
    public void testUpdateAppointmentDescription() {
        final Calendar calendar = Calendar.getInstance();
        calendar.add(5, 1);
        final Date appointmentDate = calendar.getTime();
        final Appointment appointment = new Appointment("A6", appointmentDate, "Meet with team");
        this.appointmentService.addAppointment(appointment);
        this.appointmentService.updateAppointmentDescription("A6", "Updated description");
        Assert.assertEquals((Object)"Updated description", (Object)this.appointmentService.getAppointment("A6").getDescription());
    }
}
