package contactService;

import java.util.Iterator;
import java.util.HashMap;
import contact.Contact;
import java.util.Map;

public class ContactService
{
    private Map<String, Contact> contacts;
    
    public ContactService() {
        this.contacts = new HashMap<String, Contact>();
    }
    
    public void addContact(final Contact contact) {
        this.contacts.put(contact.getContactID(), contact);
    }
    
    public void deleteContact(final String contactID) {
        this.contacts.remove(contactID);
    }
    
    public boolean updateContact(final String contactID, final String firstName, final String lastName, final String phoneNumber, final String address) {
        final Contact contact = this.contacts.get(contactID);
        if (contact != null) {
            for (final Contact contactList : this.contacts.values()) {
                if (!contactList.getContactID().equals(contactID) && (firstName.equals(contactList.getFirstName()) || lastName.equals(contactList.getLastName()) || phoneNumber.equals(contactList.getPhoneNumber()) || address.equals(contactList.getAddress()))) {
                    return false;
                }
            }
            if (!firstName.isEmpty()) {
                contact.setFirstName(firstName);
            }
            if (!lastName.isEmpty()) {
                contact.setLastName(lastName);
            }
            if (!phoneNumber.isEmpty()) {
                contact.setPhoneNumber(phoneNumber);
            }
            if (!address.isEmpty()) {
                contact.setAddress(address);
            }
            return true;
        }
        return false;
    }
    
    public Contact getContact(final String contactID) {
        return this.contacts.get(contactID);
    }
}
