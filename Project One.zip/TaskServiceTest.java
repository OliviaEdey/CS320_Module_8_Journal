package taskServiceTest;

import org.junit.Test;
import org.junit.Assert;
import task.Task;
import org.junit.Before;
import taskService.TaskService;

public class TaskServiceTest
{
    private TaskService taskService;
    
    @Before
    public void setUp() throws Exception {
        this.taskService = new TaskService();
    }
    
    @Test
    public void testAddTask() {
        final Task task = new Task("T1", "Get Supplies", "Get pens, markers and folders");
        this.taskService.addTask(task);
        Assert.assertEquals((Object)task, (Object)this.taskService.getTask("T1"));
    }
    
    @Test
    public void testDeleteTask() {
        final Task task = new Task("T2", "Get Supplies", "Get pens, markers and folders");
        this.taskService.addTask(task);
        this.taskService.deleteTask("T2");
        Assert.assertNull((Object)this.taskService.getTask("T2"));
    }
    
    @Test
    public void testUpdateTaskName() {
        final Task task = new Task("T3", "Get Supplies", "Get pens, markers and folders");
        this.taskService.addTask(task);
        this.taskService.updateTaskName("T3", "Get paperclips");
        Assert.assertEquals((Object)"Get paperclips", (Object)this.taskService.getTask("T3").getTaskName());
    }
    
    @Test
    public void testUpdateTaskDescription() {
        final Task task = new Task("T4", "Get Supplies", "Get pens, markers and folders");
        this.taskService.addTask(task);
        this.taskService.updateTaskDescription("T4", "Get papers");
        Assert.assertEquals((Object)"Get papers", (Object)this.taskService.getTask("T4").getTaskDescription());
    }
}
