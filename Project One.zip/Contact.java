package contact;

public class Contact
{
    private String contactID;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;
    
    public Contact(final String contactID, final String firstName, final String lastName, final String phoneNumber, final String address) {
        if (contactID != null && contactID.length() <= 10) {
            this.contactID = contactID;
            this.contactID = contactID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.address = address;
            return;
        }
        throw new IllegalArgumentException("Contact ID must not be null and should be up to 10 characters long.");
    }
    
    public String getContactID() {
        return this.contactID;
    }
    
    public void setContactID(final String contactID) {
        if (contactID != null && contactID.length() <= 10) {
            this.contactID = contactID;
            return;
        }
        throw new IllegalArgumentException("Contact ID must not be null and should be up to 10 characters long.");
    }
    
    public String getFirstName() {
        return this.firstName;
    }
    
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return this.lastName;
    }
    
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }
    
    public String getPhoneNumber() {
        return this.phoneNumber;
    }
    
    public void setPhoneNumber(final String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public void setAddress(final String address) {
        this.address = address;
    }
    
    @Override
    public String toString() {
        return "Contact [ contactID= " + this.contactID + ", firstName = " + this.firstName + ", lastName = " + this.lastName + ", phoneNumber = " + this.phoneNumber + ", address = " + this.address + " ]";
    }
}
