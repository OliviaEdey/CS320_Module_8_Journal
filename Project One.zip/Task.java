package task;

public class Task
{
    private final String taskID;
    private String taskName;
    private String taskDescription;
    
    public Task(final String taskID, final String taskName, final String taskDescription) {
        if (taskID == null || taskID.isEmpty()) {
            throw new IllegalArgumentException("Task ID cannot be null or empty");
        }
        if (taskName == null || taskName.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
        if (taskName.length() > 20) {
            throw new IllegalArgumentException("Name length exceeds 20 characters");
        }
        if (taskDescription == null || taskDescription.isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (taskDescription.length() > 50) {
            throw new IllegalArgumentException("Description length exceeds 50 characters");
        }
        this.taskID = taskID;
        this.taskName = taskName;
        this.taskDescription = taskDescription;
    }
    
    public String getTaskID() {
        return this.taskID;
    }
    
    public String getTaskName() {
        return this.taskName;
    }
    
    public String getTaskDescription() {
        return this.taskDescription;
    }
    
    public void setTaskName(final String taskName) {
        if (taskName == null || taskName.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
        if (taskName.length() > 20) {
            throw new IllegalArgumentException("Name length exceeds 20 characters");
        }
        this.taskName = taskName;
    }
    
    public void setTaskDescription(final String taskdescription, final String taskDescription) {
        if (taskDescription == null || taskDescription.isEmpty()) {
            throw new IllegalArgumentException("Description cannot be null or empty");
        }
        if (taskDescription.length() > 50) {
            throw new IllegalArgumentException("Description length exceeds 50 characters");
        }
        this.taskDescription = taskDescription;
    }
}
