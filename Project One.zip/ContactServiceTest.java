package contactServiceTest;

import org.junit.Test;
import org.junit.Assert;
import contact.Contact;
import org.junit.Before;
import contactService.ContactService;

public class ContactServiceTest
{
    private ContactService contactService;
    
    @Before
    public void setUp() throws Exception {
        this.contactService = new ContactService();
    }
    
    @Test
    public void testAddContact() {
        final Contact contact = new Contact("1", "Sharon", "Smith", "1246810120", "6 Palm St");
        this.contactService.addContact(contact);
        Assert.assertEquals((Object)contact, (Object)this.contactService.getContact("1"));
    }
    
    @Test
    public void testDeleteContact() {
        final Contact contact = new Contact("1", "Sharon", "Smith", "1246810120", "6 Palm St");
        this.contactService.addContact(contact);
        this.contactService.deleteContact("1");
        Assert.assertNull((Object)this.contactService.getContact("1"));
    }
    
    @Test
    public void testUpdateContact() {
        final Contact contact = new Contact("1", "Sharon", "Smith", "1246810120", "6 Palm St");
        this.contactService.addContact(contact);
        this.contactService.updateContact("1", "Simon", "Taylor", "9876543210", "42 Strange St");
        final Contact updatedContact = this.contactService.getContact("1");
        Assert.assertEquals((Object)"Simon", (Object)updatedContact.getFirstName());
        Assert.assertEquals((Object)"Taylor", (Object)updatedContact.getLastName());
        Assert.assertEquals((Object)"9876543210", (Object)updatedContact.getPhoneNumber());
        Assert.assertEquals((Object)"42 Strange St", (Object)updatedContact.getAddress());
    }
    
    @Test
    public void testUpdateContactOnlyFirstName() {
        final Contact contact = new Contact("2", "Don", "Jones", "1357924680", "9 Love Ln");
        this.contactService.addContact(contact);
        this.contactService.updateContact("2", "Donald", "", "", "");
        final Contact updatedContact = this.contactService.getContact("2");
        Assert.assertEquals((Object)"Donald", (Object)updatedContact.getFirstName());
        Assert.assertEquals((Object)"Jones", (Object)updatedContact.getLastName());
        Assert.assertEquals((Object)"1357924680", (Object)updatedContact.getPhoneNumber());
        Assert.assertEquals((Object)"9 Love Ln", (Object)updatedContact.getAddress());
    }
    
    @Test
    public void testUpdateContactInvalidContactID() {
        final boolean result = this.contactService.updateContact("3", "CJ", "Fields", "2525252525", "77 Green St");
        Assert.assertFalse(result);
    }
    
    @Test
    public void testUpdateContactWithExistingData() {
        final Contact contact1 = new Contact("4", "Alicia", "Pines", "1234567890", "2 Tiles Rd");
        final Contact contact2 = new Contact("5", "Seline", "Charles", "4523645236", "4 River Rd");
        this.contactService.addContact(contact1);
        this.contactService.addContact(contact2);
        final boolean result = this.contactService.updateContact("4", "Seline", "Charles", "4523645236", "4 River Rd");
        Assert.assertFalse(result);
    }
}
