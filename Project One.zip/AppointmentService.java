package appointmentService;

import java.util.HashMap;
import appointment.Appointment;
import java.util.Map;

public class AppointmentService
{
    private Map<String, Appointment> appointments;
    
    public AppointmentService() {
        this.appointments = new HashMap<String, Appointment>();
    }
    
    public void addAppointment(final Appointment appointment) {
        this.appointments.put(appointment.getAppointmentID(), appointment);
    }
    
    public void deleteAppointment(final String appointmentID) {
        this.appointments.remove(appointmentID);
    }
    
    public Appointment getAppointment(final String appointmentID) {
        return this.appointments.get(appointmentID);
    }
    
    public Map<String, Appointment> getAllAppointments() {
        return this.appointments;
    }
    
    public void updateAppointmentDescription(final String appointmentID, final String newDescription) {
        final Appointment appointment = this.appointments.get(appointmentID);
        if (appointment != null) {
            appointment.setDescription(newDescription);
        }
    }
}
