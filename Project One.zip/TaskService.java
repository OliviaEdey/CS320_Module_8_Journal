package taskService;

import java.util.HashMap;
import task.Task;
import java.util.Map;

public class TaskService
{
    private Map<String, Task> tasks;
    
    public TaskService() {
        this.tasks = new HashMap<String, Task>();
    }
    
    public void addTask(final Task task) {
        this.tasks.put(task.getTaskID(), task);
    }
    
    public void deleteTask(final String taskID) {
        this.tasks.remove(taskID);
    }
    
    public void updateTaskName(final String taskID, final String taskName) {
        final Task task = this.tasks.get(taskID);
        if (task != null) {
            task.setTaskName(taskName);
        }
    }
    
    public void updateTaskDescription(final String taskID, final String taskDescription) {
        final Task task = this.tasks.get(taskID);
        if (task != null) {
            task.setTaskDescription(taskID, taskDescription);
        }
    }
    
    public Task getTask(final String taskID) {
        return this.tasks.get(taskID);
    }
    
    public Map<String, Task> getAllTasks() {
        return this.tasks;
    }
}
