package taskTest;

import org.junit.Test;
import org.junit.Assert;
import task.Task;
import org.junit.Before;

public class TaskTest
{
    @Before
    public void setUp() throws Exception {
    }
    
    @Test
    public void testValidTaskCreation() {
        final Task task = new Task("T1", "Get Supplies", "Get pens, markers and folders");
        Assert.assertEquals((Object)"T1", (Object)task.getTaskID());
        Assert.assertEquals((Object)"Get Supplies", (Object)task.getTaskName());
        Assert.assertEquals((Object)"Get pens, markers and folders", (Object)task.getTaskDescription());
    }
    
    @Test
    public void testInvalidTaskCreation() {
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task(null, "Get Supplies", "Get pens, markers and folders"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task("T2", null, "Get pens, markers and folders"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task("T3", "Get Supplies", null));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task("T4", "Get Supplies", ""));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task("T5", "Get Supplies", "Get a very long description exceeding fifty characters"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task("T6", "Get Supplies2468102", "Get pens, markers and folders"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Task("T7", "Get Supplies", "Get pens, markers and folders2468102"));
    }
    
    @Test
    public void testUpdateTaskName() {
        final Task task = new Task("T8", "Get Supplies", "Get pens, markers and folders");
        task.setTaskName("Get paperclips");
        Assert.assertEquals((Object)"Get paperclips", (Object)task.getTaskName());
    }
    
    @Test
    public void testUpdateTaskDescription() {
        final Task task = new Task("T9", "Get Supplies", "Get pens, markers and folders");
        task.setTaskDescription("Get papers", null);
        Assert.assertEquals((Object)"Get papers", (Object)task.getTaskDescription());
    }
}
