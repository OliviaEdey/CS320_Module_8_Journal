package appointmentTest;

import org.junit.Test;
import java.util.Date;
import org.junit.Assert;
import appointment.Appointment;
import java.util.Calendar;
import org.junit.Before;

public class AppointmentTest
{
    @Before
    public void setUp() throws Exception {
    }
    
    @Test
    public void testValidAppointmentCreation() {
        final Calendar calendar = Calendar.getInstance();
        calendar.add(5, 1);
        final Date appointmentDate = calendar.getTime();
        final Appointment appointment = new Appointment("A1", appointmentDate, "Meet with team");
        Assert.assertEquals((Object)"A1", (Object)appointment.getAppointmentID());
        Assert.assertEquals((Object)appointmentDate, (Object)appointment.getAppointmentDate());
        Assert.assertEquals((Object)"Meet with team", (Object)appointment.getDescription());
    }
    
    @Test
    public void testInvalidAppointmentCreation() {
        final Calendar calendar = Calendar.getInstance();
        final Date pastDate = calendar.getTime();
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment(null, pastDate, "Meet with team"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment("A2", null, "Meet with team"));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment("A3", pastDate, null));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment("A4", pastDate, ""));
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment("A5", pastDate, "A very long description exceeding fifty characters"));
        calendar.add(5, -1);
        final Date pastAppointmentDate = calendar.getTime();
        Assert.assertThrows((Class)IllegalArgumentException.class, () -> new Appointment("A6", pastAppointmentDate, "Meet with team"));
    }
    
    @Test
    public void testUpdateAppointmentDate() {
        final Calendar calendar = Calendar.getInstance();
        calendar.add(5, 1);
        final Date initialDate = calendar.getTime();
        final Appointment appointment = new Appointment("A7", initialDate, "Meet with team");
        calendar.add(5, 2);
        final Date updatedDate = calendar.getTime();
        appointment.setAppointmentDate(updatedDate);
        Assert.assertEquals((Object)updatedDate, (Object)appointment.getAppointmentDate());
    }
    
    @Test
    public void testUpdateAppointmentDescription() {
        final Calendar calendar = Calendar.getInstance();
        calendar.add(5, 1);
        final Date appointmentDate = calendar.getTime();
        final Appointment appointment = new Appointment("A8", appointmentDate, "Meet with team");
        appointment.setDescription("Updated description");
        Assert.assertEquals((Object)"Updated description", (Object)appointment.getDescription());
    }
}
